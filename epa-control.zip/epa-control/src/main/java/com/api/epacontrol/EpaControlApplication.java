package com.api.epacontrol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EpaControlApplication {

	public static void main(String[] args) {
		SpringApplication.run(EpaControlApplication.class, args);
	}

}
