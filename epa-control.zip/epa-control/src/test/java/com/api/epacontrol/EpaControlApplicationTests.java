package com.api.epacontrol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EpaControlApplicationTests {

	@Test
	void contextLoads() {
	}

}
